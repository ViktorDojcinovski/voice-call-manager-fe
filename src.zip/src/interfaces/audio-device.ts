interface AudioDevice {
  id: string;
  label: string;
  isActive: boolean;
  type: string;
}

export { AudioDevice };
