type CallResult = {
  label: string;
  _id: string;
  checked: boolean;
};

export { CallResult };
