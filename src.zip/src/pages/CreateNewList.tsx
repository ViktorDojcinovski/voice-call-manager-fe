import MultiStepForm_CreateNewList from "../components/forms/createList/MultiStepCreateList";

const CreateNewList = () => {
  return (
    <>
      <MultiStepForm_CreateNewList />
    </>
  );
};

export default CreateNewList;
