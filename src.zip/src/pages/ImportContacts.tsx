import MultiStep_ContactsImport from "../components/forms/contactsImport/MultiStep_ContactsImport";

const ImportContacts = () => {
  return (
    <>
      <MultiStep_ContactsImport />
    </>
  );
};

export default ImportContacts;
